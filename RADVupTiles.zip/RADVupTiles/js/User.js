﻿

;var User = function (param) {
    this.firstName = param.firstName;
    this.lastName = param.lastName;
    this.photo = param.photo;
    this.profileData = param.profileData;
    this.isAnonymous = param.isAnonymous;
};